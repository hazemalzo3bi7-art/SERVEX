# CLAUDE 3 FINDINGS — VERIFICATION REVIEW
Date: 2026-10-01 · Scope: documentation + backend-contract review · No code, SQL, DB or Supabase was changed.

## Evidence available to this review (and what was missing)
Available: the 17 repo docs and the logo file. **Missing: `src/**`, `supabase/_drafts/**`, `tests/**`, `package.json`, `README.md`, `AGENTS.md`, `docs/MASTER_PROMPT.md`, `.git`.** The review could not check code or SQL.

Status meanings:
- **VERIFIED** = confirmed in the repo documentation files (or the logo file) that I could read. This does NOT prove the code/SQL behaves that way.
- **NOT VERIFIED** = needs a file I did not have; the file to check is named. Nothing is guessed.
- **FALSE/OUTDATED** = the finding is wrong or already stale.

## Verification table
| ID | Claude 3 finding | Status | Evidence / file still needed | Action |
|---|---|---|---|---|
| S1 | DEMO_MODE is a hard-coded constant; OTP/demo users exposed; no release gate | **VERIFIED, with correction** | KI-014, D-019, FILE_MAP (`seed.ts`). Correction: docs say the flag controls the demo hint on the login screen. Whether OTP `123456` and the seeded admin still work when it is false is NOT VERIFIED (`memoryAuthService.ts`, `services/auth/index.ts`). Claude 3's wording implied the flag gates the OTP; that is unproven. "No automated gate" = absence in docs only (`package.json` unseen) | Documented as KI-021. Frontend not changed (instruction). Release rule: replace in-memory auth (Phase 22) + add a gate |
| S2 | `/dev/components` ships | VERIFIED (docs) | KI-010; code not seen | Existing KI-010 |
| S3 | RLS only tested on plain PostgreSQL with stand-ins | VERIFIED (docs) | KI-016, TESTING caveat. RLS correctness itself NOT VERIFIED (`0005_rls.sql`) | Documented (existing) |
| S4 | Same agent wrote stubs + checks | VERIFIED (docs) | DEVELOPMENT_LOG (stubs and 22 checks "wrote") | Recorded in KI-022 |
| S5 | Storage policies untested; no rate limit/backups/cron | VERIFIED (docs) | DATABASE_PLAN gaps, SECURITY | Future (Phase 20/22) |
| S6 | 60 s per-phone lockout enables login DoS in a real backend | NOT VERIFIED | Prospective inference, not a defect in the demo. Needs real Supabase/SMS design | Future (Phase 22); recorded here |
| C1 | Two sources of truth for the job state machine | **VERIFIED, refined** | ARCHITECTURE #2, API_PLAN, DATABASE_PLAN (32-row table). Tree shows `src/features/jobs/` holds only `.gitkeep`, so the TS machine does **not exist yet**; no drift today, the risk is prospective. 14 state names/32 transitions are in no repo doc (NOT VERIFIED, needs SQL + master prompt) | KI-019 (decide mechanism BEFORE jobs work). Not decided here |
| C2 | KI-016: verified phone never copied to `profiles.phone` | VERIFIED (docs) | KI-016, DATABASE_PLAN. Gap itself in SQL NOT VERIFIED | **Not fixed**: needs SQL I cannot see, and drafts must not be edited without owner. Phase 22 prep (existing) |
| C3 | Pricing in both mock service and Edge Functions | VERIFIED (docs), prospective | ARCHITECTURE #3, API_PLAN | KI-020 |
| C4 | Reconciliation deferred to Phase 22 | VERIFIED (docs) | DATABASE_PLAN, KI-017 | KI-023: Phase 3/4 must align with DB `categories`/`services` |
| C5 | Two demo-data sources may drift | VERIFIED existence; drift NOT VERIFIED | `seed.ts` vs `seed.sql`/`generate_seed.py` contents unseen | KI-023 |
| C6 | Multi-country principle vs Jordan-only DB (JOD, phone CHECK) | VERIFIED (docs) | ARCHITECTURE #6, DATABASE_PLAN | Documented; needs owner statement that Jordan-only is intentional |
| C7 | "Nearby providers" vs no PostGIS | VERIFIED (docs) | DATABASE_PLAN lists PostGIS as a gap; map provider undecided (ROADMAP) | Future (Phase 5/23) |
| C8 | Payment/commission/inspection tables exist before decisions | VERIFIED (docs); whether schema is gateway-specific NOT VERIFIED | ROADMAP vs DATABASE_PLAN | KI-020 |
| C9 | TS money representation undecided | NOT VERIFIED (inference) | No code exists to contradict; DB uses numeric(…,3) | Open decision (KI-020) |
| C10 | `reviews` vs ratings; extra `deleted` status | VERIFIED (docs) | KI-017, DATABASE_PLAN reconciliation table | Existing; no rename chosen (not my decision) |
| C11 | files_zip carries its own DATABASE_PLAN.md/BACKEND_HANDOFF.md | VERIFIED (docs) | SESSION_HANDOFF tree | No action; noted |
| P1 | Master prompt not in repo | VERIFIED | AI_INSTRUCTIONS #9; tree has no `MASTER_PROMPT.md`. Whether the owner added it since: NOT VERIFIED | KI-024 |
| P2 | No git remote/CI | VERIFIED as of last handoff; current state NOT VERIFIED | SESSION_HANDOFF "Backup Status" | KI-025 |
| P3 | SQL comparison asymmetric (checks only for claude22) | VERIFIED (docs) | DATABASE_PLAN table, D-024 | KI-022; drafts NOT merged |
| P4 | Stale docs (5 items) | **VERIFIED, all five** | PROJECT_STATUS "Next task: Phase 1"; TESTING `nav_smoke.py`; RESEARCH not-yet-done list; FILE_MAP `_layout.tsx`; ENVIRONMENT. Extra find: SESSION_HANDOFF listed OptionCard under Phase 1 though created in Phase 2 | **FIXED** (docs) |
| P5 | `verify` = tsc+eslint only; tests manual, Linux-based | VERIFIED (docs) | TESTING "Commands" | Clarified in TESTING/ENVIRONMENT; CI is future |
| P6 | i18n/forms library never decided | VERIFIED (docs) | D-005 (Phase 1), D-015 (Phase 2), no later decision | Noted in RESEARCH; decision left open |
| P7 | SDK 58 upgrade will affect RTL/Expo Go | VERIFIED (docs) | D-001, D-011, KI-003 | Existing |
| P8 | `C:\\Dev` typo in handoff | **FALSE/OUTDATED** | `\\` is a Markdown escape that renders as one backslash | None. Claude 3 report corrected |
| U1-U3 | Native unknown; no screen-reader test; toast single slot; UX study deferred | VERIFIED (docs) | KI-001/006/008/018, TESTING, RESEARCH. "Toast not announced" NOT VERIFIED (`Toast.tsx`) | Existing |
| U6 | Logo is a comparison sheet, Latin only | VERIFIED (file) | `servex_logo_candidate.png` 1327×301, two variants with captions. Whether repo copy `docs/brand/` is identical: NOT VERIFIED | Documented (D-025) |
| M1 | Possibly missing DB tables (saved addresses, push tokens, messaging, tracking, support, promo) | **NOT VERIFIED** | Doc table list lacks them; `0002`/`0003` SQL needed | Handoff item |
| M2 | `search_path`, `create_job` provider choice/re-offer, `transition_job` sole writer, anon grants | **NOT VERIFIED** | `0004_functions.sql`, `0005_rls.sql` | Handoff item |
| X1 | Claude 1/2 roles undefined | VERIFIED (not in docs) | No doc uses the names | KI-025: owner to define |
| X2 | "Phase 8 = pricing" (Claude 3 reports) | **FALSE/OUTDATED** | ROADMAP only says pricing/commission decisions are due "before 8" | **Corrected** in Claude 3 reports |
| V1-V4 | 26 tables counted; phone rule consistent; JOD 3 decimals; test counts consistent | VERIFIED (docs) | DATABASE_PLAN, TESTING, STATUS | — |

## Corrections made to Claude 3's own reports
1. S1 reworded (flag effect on OTP unproven). 2. "Phase 8 pricing" reworded to "pricing/commission decisions due before Phase 8". 3. P8 removed (false). 4. Header added pointing to this review.

## Fixed in this review (documentation only)
PROJECT_STATUS, TESTING, RESEARCH, ENVIRONMENT, FILE_MAP, KNOWN_ISSUES (KI-019..025), DEVELOPMENT_LOG, SESSION_HANDOFF.

## Deliberately NOT done
No change to code, SQL drafts, DB, Supabase, DECISIONS.md (no business decision made), ROADMAP. No merge of the two SQL drafts. No DEMO_MODE gate (frontend). No state-machine/pricing mechanism chosen. No Git checkpoint (no repository in the session).

## Phase 3 dependencies (from docs)
1. Owner: "Servex" final? 2. Owner: confirm claude22 as SQL base. 3. UX study (RESEARCH). 4. Demo categories/services must align with DB `categories`/`services` (read `0002_core_tables.sql` first; KI-023). 5. Do not add job-state or pricing logic yet (KI-019/020). None of these is a new blocker found by this review; items 1-3 were already gates.
